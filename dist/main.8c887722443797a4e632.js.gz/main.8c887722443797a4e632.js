console.log("Hello funny world");
//# sourceMappingURL=main.8c887722443797a4e632.js.map